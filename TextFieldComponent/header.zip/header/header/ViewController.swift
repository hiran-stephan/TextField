//
//  ViewController.swift
//  header
//
//  Created by Hiran Stephan on 30/01/25.
//

import UIKit

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var headerView: UIView!  // Header View
    @IBOutlet weak var titleLabel: UILabel!  // Title Label
    @IBOutlet weak var subtitleLabel: UILabel!  // Subtitle Label
    @IBOutlet weak var bottomView: UIView!  // View below subtitleLabel
    
    var shouldShowSubtitle = false // Toggle this condition to test hiding/showing
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        // Set title text
        titleLabel.text = "Header Title"
        
        // Show or hide subtitle conditionally
        if shouldShowSubtitle {
            subtitleLabel.text = "This is the subtitle for the header."
            subtitleLabel.isHidden = false
        } else {
            subtitleLabel.isHidden = true
            subtitleLabel.text = nil // Remove text to clear intrinsic height
        }
        
        // Ensure Auto Layout updates dynamically
        updateHeaderViewHeight()
    }

    // MARK: - Update Header Height Dynamically
    func updateHeaderViewHeight() {
        guard let headerView = self.headerView else { return }
        
        // Force Auto Layout update
        headerView.setNeedsLayout()
        headerView.layoutIfNeeded()

        // If subtitleLabel is hidden, ensure it's collapsed
        if subtitleLabel.isHidden {
            subtitleLabel.heightAnchor.constraint(equalToConstant: 0).isActive = true
        }
        
        // Make sure bottomView moves up when subtitleLabel is hidden
        bottomView.topAnchor.constraint(equalTo: subtitleLabel.bottomAnchor, constant: subtitleLabel.isHidden ? 0 : 8).isActive = true
        
        // Get correct height after layout update
        let height = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height
        
        var frame = headerView.frame
        frame.size.height = height
        headerView.frame = frame
        
        // Assign the updated headerView to tableView
        tableView.tableHeaderView = headerView
    }
    
    // MARK: - UITableView DataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20 // Number of rows
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "Row \(indexPath.row + 1)"
        return cell
    }
}

